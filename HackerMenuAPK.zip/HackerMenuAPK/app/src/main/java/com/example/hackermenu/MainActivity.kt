package com.example.hackermenu

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val neon = Color.rgb(0, 255, 136)
    private val bg = Color.rgb(5, 9, 7)
    private val panel = Color.rgb(10, 18, 14)
    private lateinit var scriptsArea: LinearLayout
    private val importedFiles = mutableListOf<String>()
    private val pickScript = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(16))
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "⌁  HACKER MENU"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(neon)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        root.addView(header)
        val sub = TextView(this).apply {
            text = "MOD MENU  •  V1.0  •  OFFLINE"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(8), 0, 0, dp(14))
        }
        root.addView(sub)

        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("INÍCIO", "SCRIPTS", "AJUSTES").forEach { label ->
            nav.addView(makeButton(label) {
                Toast.makeText(this, "$label selecionado", Toast.LENGTH_SHORT).show()
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        }
        root.addView(nav)

        val title = TextView(this).apply {
            text = "\n▣  MEUS SCRIPTS"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(neon)
            setPadding(dp(4), dp(6), 0, dp(8))
        }
        root.addView(title)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(panel)
            isFillViewport = true
        }
        scriptsArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        scroll.addView(scriptsArea)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { bottomMargin = dp(12) })
        refreshScripts()

        root.addView(makeButton("＋  IMPORTAR ARQUIVO (.TXT / .JS)") { openPicker() },
            LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        root.addView(makeButton("LIMPAR LISTA") {
            importedFiles.clear()
            refreshScripts()
            Toast.makeText(this, "Lista limpa", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(-1, dp(46)))

        val note = TextView(this).apply {
            text = "\nOs arquivos são apenas listados; não são executados pelo aplicativo."
            textSize = 11f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
        }
        root.addView(note)
        setContentView(root)
    }

    private fun refreshScripts() {
        scriptsArea.removeAllViews()
        if (importedFiles.isEmpty()) {
            scriptsArea.addView(TextView(this).apply {
                text = "\n\nNENHUM SCRIPT ADICIONADO\n\nImporte um arquivo para listá-lo aqui.\n\n"
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(neon)
            }, LinearLayout.LayoutParams(-1, dp(250)))
        } else {
            importedFiles.forEach { file ->
                scriptsArea.addView(TextView(this).apply {
                    text = "▸  $file"
                    textSize = 15f
                    setTextColor(Color.WHITE)
                    setPadding(dp(10), dp(14), dp(10), dp(14))
                    setBackgroundColor(Color.rgb(16, 28, 21))
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
            }
        }
    }

    private fun openPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/plain", "application/javascript", "text/javascript"))
        }
        try { startActivityForResult(intent, pickScript) }
        catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir os arquivos", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android API; retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickScript && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "script_importado"
            if (!importedFiles.contains(name)) importedFiles.add(name)
            refreshScripts()
            Toast.makeText(this, "Arquivo adicionado à lista", Toast.LENGTH_SHORT).show()
        }
    }

    private fun makeButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setTextColor(neon)
        setBackgroundColor(Color.rgb(12, 29, 20))
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
