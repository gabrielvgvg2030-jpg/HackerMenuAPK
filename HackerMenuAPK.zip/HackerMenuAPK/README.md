# Hacker Menu — projeto Android inicial

Projeto Android nativo em Kotlin, com tema escuro e detalhes verde-neon. Inclui abas demonstrativas, importação de arquivos para uma lista e limpeza da lista.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `HackerMenuAPK` no Android Studio.
3. Aguarde a sincronização do Gradle e instale os componentes do SDK solicitados.
4. Use **Build > Build APK(s)**.
5. O APK de depuração normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP contém o código-fonte, não um APK já compilado. A importação só lista nomes de arquivos: scripts não são executados. Use apenas em projetos e ambientes autorizados.
